
<?php
require 'conn.php';
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="contact.css">
    <title>Contact Us</title>
  </head>
  <body>
    <div class="main">
      <div class="container-card">
        <div class="aligned">
          <h1 style="text-align: left;">Contact Us</h1><br>


        <div class="wrapper">  
        <div id="error_message"></div>


        <form method="post" id="myform" name="ContactForm" onsubmit="return validation();" action=<?php submit_query($conn)?>>




          <!--<input type="text" name="First Name" placeholder="First Name" id="firstname" class="in"><br><br>
          <input type="text" name="Last Name" placeholder="Last Name" id="lastname" class="in"><br><br>
          <input type="text" name="Phone" placeholder="Phone Number" id="phone" class="in"><br><br>
          <input type="email" name="Email" placeholder="Email-ID" id="emailid" class="in"><br><br>
          <textarea name="Query" rows="5" cols="50" placeholder="Query" id="message1" class="in"></textarea><br><br><br>
          <textarea name="Feedback" rows="5" cols="50" placeholder="Feedback" class="in"></textarea><br><br><br>-->
          


            <label for="First Name" class="nm">First Name:</label><br><br>
            
            <input type="text" name="first_name" id="firstname" class="in"><br><br>

            <label for="Last Name" class="nm">Last Name:</label><br><br>

            <input type="text" name="last_name" id="lastname" class="in"><br><br>

            <label for="Phone Number" class="nm">Phone Number:</label><br><br>

            <input type="text" name="phone" placeholder="Phone Number" id="phone" class="in"><br><br>

            <label for="Email" class="nm">E-mail ID:</label><br><br>

            <input type="email" name="email" id="emailid" class="in"><br><br>

            <label for="Query" class="nm">Query:</label><br><br>

            <textarea name="query" rows="5" cols="50" id="message1" class="in"></textarea><br><br><br>

            <h4>Please take out your valuable time to provide us a feedback.</h4><br><br>

            <label for="Feedback" class="nm">Feedback:</label><br><br>

            <textarea name="feedback" rows="5" cols="50" class="in"></textarea><br><br><br>

            <button type="submit" name="button" class="submit custom-btn btn">Submit</button><br>
          </form>
        </div>
      </div>
    </div>
  </body>

<?php


function submit_query($conn){
  
  if(isset($_POST['button'])){
    $first_name=$_POST['first_name'];
    $last_name=$_POST['last_name'];
    $phone_no=$_POST['phone'];
    $email=$_POST['email'];
    $query=$_POST['query'];
    $feedback=$_POST['feedback'];
  
    $sql="insert into farmer(first_name,last_name,phone,email,query,feedback) values ('$first_name','$last_name','$phone_no','$email','$query','$feedback')";
    if(mysqli_query($conn,$sql)){
      header('Location: Contact_pulkit.php');
  }else{
      echo "eror";
  }
  }
}

?>





  <script>
    function validation(){
    var firstname = document.getElementById("firstname").value;
    var lastname = document.getElementById("lastname").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("emailid").value;
    var message1 = document.getElementById("message1").value;
    var error_message = document.getElementById("error_message");
    var text;
    var regName = /^([a-zA-Z ]){2,30}$/;
    var regphone = /^[0-9]{10}$/;
    var regemail = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;

    error_message.style.padding = "10px";

    if(!regName.test(firstname)){
      text = "Please Enter Valid First Name";
      error_message.innerHTML = text;
      return false;
    }
    
    if(!regName.test(lastname)){
      text = "Please Enter Valid Last Name";
      error_message.innerHTML = text;
      return false;
    }

    if(!regphone.test(phone)){
      text = "Please Enter Valid Mobile Number";
      error_message.innerHTML = text;
      return false;
    }
    
    if(!regemail.test(email)){
      text = "Please Enter Valid Email Address";
      error_message.innerHTML = text;
      return false;
    }

 

  }

</script>
</html>